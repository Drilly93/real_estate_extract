import geopandas as gpd
import pandas as pd
import requests
from shapely.geometry import Point
from geopy.geocoders import Nominatim
import time
import base64
from io import BytesIO
from pdfminer.high_level import extract_text



gdf_plui = gpd.read_file(r"cadastre-35-parcelles-shp\parcelles.shp")


def chercher_parcelle(adresse: str) -> str:
    """
    Recherche l'identifiant de la zone PLUI correspondant à une adresse donnée.

    La fonction procède de la manière suivante :
      1. Elle utilise Nominatim pour géocoder l'adresse et obtenir ses coordonnées.
      2. Elle crée un objet Point à partir des coordonnées géographiques obtenues.
      3. Un GeoDataFrame est créé pour ce point avec le CRS EPSG:4326 (WGS84).
      4. Si nécessaire, le GeoDataFrame du point est reprojeté dans le même CRS que
         le GeoDataFrame des zones PLUI.
      5. Une jointure spatiale est réalisée pour déterminer la zone PLUI qui contient le point.
      6. Si une zone correspondante est trouvée, l'identifiant unique ('id') de la première zone
         est retourné ; sinon, un message explicite est renvoyé.

    Paramètres:
        adresse (str): L'adresse à rechercher dans les zones PLUI.

    Retourne:
        str: L'identifiant de la zone PLUI contenant l'adresse, ou un message d'erreur si
             le géocodage échoue ou si aucune zone ne contient le point.
    """
    
    
    geolocator = Nominatim(user_agent="plui_geocoder")
    try:
        location = geolocator.geocode(adresse)
        time.sleep(1)
    except Exception as e:
        return f"Erreur lors du géocodage : {e}"

    if location:
        point = Point(location.longitude, location.latitude)
        gdf_point = gpd.GeoDataFrame([[adresse, point]], columns=["adresse", "geometry"], crs="EPSG:4326")
        if gdf_plui.crs != gdf_point.crs:
            gdf_point = gdf_point.to_crs(gdf_plui.crs)
        point_geom = gdf_point.iloc[0].geometry
        zones_trouvees = gdf_plui[gdf_plui.contains(point_geom)]
        if not zones_trouvees.empty:
            id_zone = zones_trouvees['id'].unique()[0]
            return id_zone
        else:
            print("Aucune zone PLUI ne contient cette adresse.")
            return "Aucune zone PLUI ne contient cette adresse."
    else:
        print("L'adresse n'a pas pu être géocodée.")
        return "L'adresse n'a pas pu être géocodée."


def extract_pdf_bytes(url: str) -> bytes:
    """
    Appelle l'API via l'URL fournie, vérifie la réponse et décode le PDF encodé en base64.
    
    Args:
        url (str): L'URL de l'API qui retourne le JSON contenant le payload encodé.
        
    Returns:
        bytes: Les octets du PDF décodé.
        
    Raises:
        ValueError: Si l'appel API échoue ou si le payload est manquant.
    """
    response = requests.get(url)
    if response.status_code != 200:
        raise ValueError(f"Échec de la récupération des données. Code de status : {response.status_code}")
    
    json_data = response.json()
    if "payload" not in json_data:
        raise ValueError("Clé 'payload' manquante dans la réponse de l'API")
    
    pdf_bytes = base64.b64decode(json_data["payload"])
    return pdf_bytes

def extract_text_from_pdf_bytes(pdf_bytes: bytes) -> str:
    """
    Extrait le texte d'un PDF représenté sous forme d'octets.
    
    Args:
        pdf_bytes (bytes): Les octets du PDF à analyser.
        
    Returns:
        str: Le texte extrait du PDF.
    """
    pdf_file = BytesIO(pdf_bytes)
    text = extract_text(pdf_file)
    return text

def save_pdf_to_file(pdf_bytes: bytes, file_path: str) -> None:
    """
    Sauvegarde les octets d'un PDF dans un fichier.
    
    Args:
        pdf_bytes (bytes): Les octets du PDF à sauvegarder.
        file_path (str): Le chemin complet (avec nom de fichier) où sauvegarder le PDF.
    """
    with open(file_path, 'wb') as f:
        f.write(pdf_bytes)


