import re

chemin_text_original = r"data/data_fiche_zone/Synthèse du règlement PLUi.txt"
with open(chemin_text_original, 'r', encoding='utf-8') as file:
    texte_original = file.read()
    
texte_separer = re.split(r"\.\r?\n+Zone", texte_original)
for i in texte_separer:
    titre = i.split("\n")[0]
    titre = titre.replace("s ","")
    while " " == titre[0]:
        titre = titre[1:]
    titre = titre.split(" ")[0]
    
    
    text = "Zone " + titre + "\n" + i
    with open(f"data/data_fiche_zone/{titre}.txt", 'w', encoding='utf-8') as file:
        file.write(text)
        print(f"Fichier {titre}.txt créé avec succès.")
