from pathlib import Path
import polars as pl


USER = "math"

if USER == "Abdel":
    
    BASE_PATH = Path.home() / "Desktop" / "ML_Project"
    BASE_PATH_DATA = BASE_PATH / "data"


    #----------------FICHIER DATA----------------#
    # Fichier csv departements francais
    PATH_FICHIER_DEP_FR = BASE_PATH_DATA /"departements_france" / "departements_france.csv" 
    
    # Chemin vers les fichiers csv des Valeurs Foncieres de chaque departements qu'on recoltera sur internet
    PATH_DIR_VAL_FONCIERE_DEP = BASE_PATH_DATA / "ValeursFoncieresParDepartement"
    
    
    # Chemin qui contiendra le fichier NETTOYE de toute les valeurs fonciere de France qui nous interesse pour notre analyse
    PATH_DIR_VAL_FONCIERE_FRANCE = BASE_PATH_DATA / "ValeursFoncieres" 
    PATH_FICHIER_VAL_FONCIERE_FRANCE = PATH_DIR_VAL_FONCIERE_FRANCE / "ValeursFoncieresFrance.csv"
    #--------------------------------------------#
    
    
elif USER == "math":
    
    
    BASE_PATH = Path.home() / "OneDrive" / "Bureau" / "M1" / "S2" / "ML_project" / "projet"
    BASE_PATH_DATA = BASE_PATH


    #----------------FICHIER DATA----------------#
    # Fichier csv departements francais
    PATH_FICHIER_DEP_FR = BASE_PATH_DATA / "data" /"depart.csv"
    
    # Chemin vers les fichiers csv des Valeurs Foncieres de chaque departements qu'on recoltera sur internet
    PATH_DIR_VAL_FONCIERE_DEP = BASE_PATH_DATA / "data" / "valeur_fonciere_depart"
    
    
    # Chemin qui contiendra le fichier NETTOYE de toute les valeurs fonciere de France qui nous interesse pour notre analyse
    PATH_DIR_VAL_FONCIERE_FRANCE = Path(r"C:\Users\mathe\OneDrive\Bureau\M1\S2\ML_project\projet\ValeursFoncieres")
    PATH_FICHIER_VAL_FONCIERE_FRANCE = PATH_DIR_VAL_FONCIERE_FRANCE / "ValeursFoncieresFrance.csv"
    #--------------------------------------------#

else :
    raise ValueError(
    "ERREUR : Utilisateur inconnu !\n"
    "Veuillez configurer vos chemins dans config.py.\n"
    "Ajoutez votre nom d'utilisateur et définissez les variables de chemin.")
    


#----------------  AUTRE CONSTANTE POUR LES DONNEES  ----------------#

# URL pour charger les valeurs foncieres de chaque departement
URL_VAL_FONCIERE = "https://dvf-api.data.gouv.fr/dvf/csv/?dep="


# Dictionnaire des types des colonnes des csv recup de internet
# On met tous en chaine de caractere, pour faciliter ensuite le nettoyage.
# Si pas en chaine de caractere, polars et pandas generent warning : ils ont du mal a inferer le type
TYPE_COLUMN_CSV_SALE = {
    "id_mutation" : pl.Utf8,
    "date_mutation" : pl.Utf8, # aaaa-mm-jj
    "numero_disposition" : pl.Utf8,
    "nature_mutation" : pl.Utf8,
    "valeur_fonciere" : pl.Utf8,
    "adresse_numero" : pl.Utf8,
    "adresse_suffixe" : pl.Utf8,
    "adresse_nom_voie" : pl.Utf8,
    "adresse_code_voie" : pl.Utf8,
    "code_postal" : pl.Utf8,
    "code_commune" : pl.Utf8,
    "nom_commune" : pl.Utf8,
    "code_departement" : pl.Utf8,
    "ancien_code_commune" : pl.Utf8 ,
    "ancien_nom_commune" : pl.Utf8,
    "id_parcelle" : pl.Utf8 ,
    "ancien_id_parcelle" : pl.Utf8,
    "numero_volume" : pl.Utf8,
    "lot1_numero" : pl.Utf8 ,
    "lot1_surface_carrez" : pl.Utf8,
    "lot2_numero" : pl.Utf8,
    "lot2_surface_carrez" : pl.Utf8,
    "lot3_numero" : pl.Utf8,
    "lot3_surface_carrez" : pl.Utf8,
    "lot4_numero" : pl.Utf8,
    "lot4_surface_carrez" : pl.Utf8,
    "lot5_numero" : pl.Utf8,
    "lot5_surface_carrez" : pl.Utf8,
    "nombre_lots" : pl.Utf8,
    "code_type_local" : pl.Utf8,
    "type_local" : pl.Utf8,
    "surface_reelle_bati" : pl.Utf8,
    "nombre_pieces_principales" : pl.Utf8,
    "code_nature_culture" : pl.Utf8,
    "nature_culture" : pl.Utf8,
    "code_nature_culture_speciale" : pl.Utf8,
    "nature_culture_speciale" : pl.Utf8,
    "surface_terrain" : pl.Utf8,
    "longitude" : pl.Utf8,
    "latitude" : pl.Utf8,
    "section_prefixe" : pl.Utf8
}



# Le Nettoyage ne gardera que certain features et convertira en type voulu. 
COLUMN_FINAL = ['date_mutation','valeur_fonciere','code_postal','nom_commune',
                'nature_mutation','code_departement','id_parcelle','type_local',
                'surface_reelle_bati','surface_terrain','longitude','latitude', 'id_mutation', 'adresse_nom_voie', 'code_commune', 'nature_culture', 'section_prefixe']
TYPE_COLUMN_CSV_PROPRE = {
    "date_mutation": pl.Date,              
    "valeur_fonciere": pl.Float64,         
    "surface_reelle_bati": pl.Float64,     
    "code_postal": pl.Utf8,                
    "nom_commune": pl.Utf8,                
    "nature_mutation": pl.Utf8,            
    "code_departement": pl.Utf8,           
    "id_parcelle": pl.Utf8,                
    "type_local": pl.Utf8,                 
    "surface_terrain": pl.Float64,         
    "longitude": pl.Float64,               
    "latitude": pl.Float64,                
    "prix_par_m2_habitable" : pl.Float64,
    "prix_par_m2_terrain" : pl.Float64,
    "annee" : pl.Int32,
    "annee_mois": pl.Utf8
}

    
