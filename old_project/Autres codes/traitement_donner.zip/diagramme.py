from pptx import Presentation
import os

def extract_text_from_pptx(pptx_path, output_txt_path):
    """
    Extrait le texte d'un fichier PowerPoint (.pptx) et le sauvegarde dans un fichier texte.
    """
    if not os.path.exists(pptx_path):
        print(f"Erreur : Le fichier '{pptx_path}' est introuvable.")
        return

    try:
        # Charger la présentation
        prs = Presentation(pptx_path)
        extracted_text = []

        # Parcourir les diapositives et extraire le texte
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    extracted_text.append(shape.text)

        # Écrire le contenu extrait dans un fichier texte
        with open(output_txt_path, 'w', encoding='utf-8') as f:
            for paragraph in extracted_text:
                f.write(paragraph + "\n")

        print(f"Texte extrait et sauvegardé dans '{output_txt_path}'")
    except Exception as e:
        print(f"Une erreur s'est produite : {e}")

# Exemple d'utilisation
if __name__ == "__main__":
    pptx_path = r'c:\Users\mathe\Downloads\cour.ppt'
    if not os.path.isfile(pptx_path):
        print(f"Erreur : Le fichier PowerPoint '{pptx_path}' n'existe pas. Veuillez vérifier le chemin.")
        exit(1)
    output_txt_path = 'resumer_cour.txt'
    extract_text_from_pptx(pptx_path, output_txt_path)