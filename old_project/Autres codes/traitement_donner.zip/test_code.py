import requests

def geocode_adresse(adresse):
    """Utilise l'API Adresse pour récupérer les coordonnées géographiques d'une adresse."""
    url = "https://api-adresse.data.gouv.fr/search/"
    params = {"q": adresse, "limit": 1}
    response = requests.get(url, params=params)
    data = response.json()
    if data["features"]:
        coords = data["features"][0]["geometry"]["coordinates"]
        return coords  # [longitude, latitude]
    return None

def get_parcelle_from_coords(lon, lat, cle_api_ign):
    """
    Utilise l'API Géoportail de l'IGN pour interroger la couche cadastrale.
    Note : L'exemple utilise un service WFS et les paramètres devront être ajustés
    en fonction de la documentation officielle de l'IGN.
    """
    wfs_url = f"https://wxs.ign.fr/{cle_api_ign}/wfs"
    # Pour une requête WFS, on définit une petite bounding box autour du point.
    delta = 0.0001  # valeur d'exemple
    bbox = f"{lon-delta},{lat-delta},{lon+delta},{lat+delta}"
    
    params = {
        "service": "WFS",
        "version": "1.0.0",
        "request": "GetFeature",
        # 'typename' dépend de la couche cadastrale utilisée, par ex. "CADASTRE:parcelles"
        "typename": "CADASTRE:parcelles",  
        "srsname": "EPSG:4326",
        "bbox": bbox,
        "outputFormat": "json"
    }
    response = requests.get(wfs_url, params=params)
    return response.json()

def adresse_to_numero_parcelle(adresse, cle_api_ign):
    # Étape 1 : Géocodage
    coords = geocode_adresse(adresse)
    if not coords:
        print("Adresse non trouvée par l'API Adresse.")
        return None
    lon, lat = coords
    print(f"Coordonnées pour l'adresse: lon={lon}, lat={lat}")

    # Étape 2 : Recherche de la parcelle via l'API IGN
    data_cadastre = get_parcelle_from_coords(lon, lat, cle_api_ign)
    # L'analyse de 'data_cadastre' dépendra de la structure de la réponse.
    # L'exemple ci-dessous est fictif et doit être adapté.
    try:
        if data_cadastre["features"]:
            parcelle_info = data_cadastre["features"][0]["properties"]
            # Supposons que la réponse contienne les champs suivants :
            insee      = parcelle_info.get("code_insee")       # ex. "35066"
            complement = parcelle_info.get("code_complement")    # ex. "6000"
            section    = parcelle_info.get("section")            # ex. "AS"
            numero     = parcelle_info.get("numero_parcelle")      # ex. "0170"
            numero_parcelle = f"{insee}{complement}{section}{numero}"
            return numero_parcelle
        else:
            print("Aucune parcelle trouvée à ces coordonnées.")
            return None
    except Exception as e:
        print("Erreur lors de l'extraction du numéro de parcelle:", e)
        return None

# Exemple d'utilisation
if __name__ == "__main__":
    adresse_exemple = "2 RUE MOLIERE Chartres-de-Bretagne"
    # Remplacez 'VOTRE_CLE_API_IGN' par votre clé d'accès à l'API Géoportail de l'IGN.
    cle_api_ign = "VOTRE_CLE_API_IGN"  
    numero_parcelle = adresse_to_numero_parcelle(adresse_exemple, cle_api_ign)
    if numero_parcelle:
        print(f"Le numéro de parcelle pour l'adresse '{adresse_exemple}' est : {numero_parcelle}")
    else:
        print("Conversion de l'adresse en numéro de parcelle a échoué.")
