import pandas as pd

# Charger les données
df = pd.read_csv('ValeursFoncieres/ValeursFoncieresFrance.csv', dtype=str)

# Sélectionner uniquement les lignes avec 'nature_mutation' == 'Vente'
df = df[df['nature_mutation'] == 'Vente']

# Garder uniquement les colonnes nécessaires
df_clean = df[[
    'id_mutation',
    'date_mutation',
    'nature_mutation',
    'valeur_fonciere',
    'adresse_nom_voie',
    'code_postal',
    'code_commune',
    'nom_commune',
    'code_departement',
    'nature_culture',
    'surface_terrain',
    'longitude',
    'latitude',
    'section_prefixe'
]]

# Convertir les colonnes en numérique pour le calcul
df_clean['valeur_fonciere'] = pd.to_numeric(df_clean['valeur_fonciere'], errors='coerce')
df_clean['surface_terrain'] = pd.to_numeric(df_clean['surface_terrain'], errors='coerce')

# Supprimer les lignes avec des valeurs manquantes ou zéro
df_clean.dropna(subset=['valeur_fonciere', 'surface_terrain'], inplace=True)
df_clean = df_clean[df_clean['surface_terrain'] > 0]

# Renommer les colonnes (si nécessaire)
df_clean.rename(columns={'section_prefixe': 'section-prefix'}, inplace=True)

# Sauvegarder le résultat

df_clean.to_csv('cleaned_data2.csv', index=False)
