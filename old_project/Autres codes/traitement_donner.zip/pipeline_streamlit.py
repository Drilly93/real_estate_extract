import streamlit as st
from info_parcelle import chercher_parcelle, extract_pdf_bytes, extract_text_from_pdf_bytes
from trouver_zone_gpt import analyse_zone, construction_possible
from pathlib import Path

# Chemin vers les fichiers de zones
chemin_info_zone = Path(__file__).parent / "data" / "data_fiche_zone"

st.title("Analyse de constructibilité d'une parcelle")

# Entrée utilisateur pour l'adresse
addresse = st.text_input("Entrez l'adresse à analyser")

if addresse:
    try:
        # Recherche de la parcelle
        numero_parcelle = chercher_parcelle(addresse)
        url = "https://api-urba.sig.rennesmetropole.fr/v1/nru/350" + numero_parcelle[2:]
        pdf_bytes = extract_pdf_bytes(url)
        info_parcelle = extract_text_from_pdf_bytes(pdf_bytes)
        # Extraction du texte PDF depuis le lien

        # Analyse de la zone et chargement des fichiers réglementaires
        zone = analyse_zone(info_parcelle).split(",")

        liste_info_zone = []
        for i in zone:
            chemin = chemin_info_zone / f"{i.strip()}.txt"
            if chemin.exists():
                with open(chemin, "r", encoding="utf-8") as file:
                    texte = file.read()
                    liste_info_zone.append(texte)
            else:
                st.warning(f"Fichier non trouvé pour la zone : {i.strip()}")

        # Agrégation de la réglementation
        loi = "\n".join(liste_info_zone)

        # Résultat final : constructibilité
        resultat = construction_possible(info_parcelle, loi)
        st.subheader("Résultat de l'analyse :")
        st.write(resultat)
        st.subheader("Info complémentaire sur la parcelle:")                
                # Bouton de téléchargement du PDF
        st.download_button(label="Télécharger le PDF",
                                data=pdf_bytes,
                                file_name="document.pdf",
                                mime="application/pdf")
        st.text(info_parcelle)

    except Exception as e:
        st.error(f"Erreur lors de l'analyse : {e}")
    
