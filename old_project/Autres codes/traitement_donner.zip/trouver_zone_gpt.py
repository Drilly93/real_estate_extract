from openai import OpenAI
import re

# ATTENTION : Gardez votre clé API en sécurité !


def analyse_zone(document_text: str) -> str:
    """
    Extrait les zones d'urbanisme auxquelles appartient juridiquement une parcelle à partir d'un texte de document.
    Renvoie une chaîne contenant uniquement les zones parmi la liste suivante, séparées par des virgules :
    1AU, 2AU, A, N, NP, UA1, UA2, UB1, UB2, UC1, UC2, UD1, UD2, UE1, UE2, UG, UI, UI1, UI2, UI3, UI4, UI5, UO, UP.
    """
    api_key = "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"
    client = OpenAI(api_key=api_key)
    prompt = f"""
Tu es un assistant spécialisé en urbanisme.

À partir des informations suivantes concernant une parcelle, identifie uniquement les zones d’urbanisme auxquelles elle appartient juridiquement.

Ne renvoie **que** les codes de zones parmi la liste suivante, séparés par des virgules et sans aucun texte supplémentaire :
1AU, 2AU, A, N, NP, UA1, UA2, UB1, UB2, UC1, UC2, UD1, UD2, UE1, UE2, UG, UI, UI1, UI2, UI3, UI4, UI5, UO, UP.

Texte : {document_text}
"""
    response = client.chat.completions.create(
        temperature=0.0,
        model="gpt-4o-mini",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    output_text = response.choices[0].message.content.strip()
    return output_text

def construction_possible_sans_info(info_parcelle: str, loi:str) -> str:
    """
    Renvoie ce qui est constructible sur la parcelle à partir de données
    """
    api_key = "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"
    client = OpenAI(api_key=api_key)
    prompt = f"""
Identifie si ces possibles de construire une maison et si oui donne ca surface au plancher maximum et le nombre d'étage.
Identifie aussi si c'est possible de construire un immeuble et la surface au plancher maximum et le nombre d'étage maximum.
Voici la loi :{loi}
Voici les infos sur la parcelle : {info_parcelle}
Renvoie l'inforamtion uniquement sous la forme suivante :
Maison : oui/non, surface au plancher maximum : X m², nombre d'étage maximum : Y, explication : texte explicatif
Immeuble : oui/non, surface au plancher maximum : X m², nombre d'étage maximum : Y, explication : texte explicatif

"""
    response = client.chat.completions.create(
        temperature=0.0,
        model="gpt-4o",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    output_text = response.choices[0].message.content.strip()
    return output_text


def extract_surface_calculated(text):
    match = re.search(r"Surface calculée de la parcelle en m²\s*[:\-]?\s*([\d\s.,]+)", text)
    if match:
        # On retire les espaces et on remplace la virgule éventuelle par un point pour obtenir un float
        number_str = match.group(1).replace(" ", "").replace(",", ".")
        return float(number_str)
    return None


def extract_vegetalisation_percentage(text):
    match = re.search(r"coefficient de végétalisation suivant\s*:\s*([\d]+)%", text, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None

def construction_possible(document_text: str, loi: str) -> str:
    """
    Renvoie ce qui est constructible sur la parcelle à partir de données
    """
    surface_calculated = extract_surface_calculated(document_text)
    vegetalisation_percentage = extract_vegetalisation_percentage(document_text)
    if surface_calculated is None:
        return construction_possible_sans_info(document_text, loi)
    else:
        if vegetalisation_percentage is None:
            return construction_possible_sans_info(document_text, loi)
        else:
            return construction_possible_avec_vege(document_text, loi, surface_calculated)

def construction_possible_avec_vege(info_parcelle: str, loi: str, surface_calculated: float, vegetalisation_percentage: int) -> str:
    """
    Renvoie ce qui est constructible sur la parcelle à partir de données
    """
    api_key = "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"
    client = OpenAI(api_key=api_key)
    surface_au_plancher_maximum = surface_calculated * (1 - vegetalisation_percentage / 100)
    prompt = f"""
Identifie si ces possibles de construire une maison et si oui ca surface au plancher maximum est de {surface_au_plancher_maximum} m² et trouve le nombre d'étage maximum.
Identifie aussi si c'est possible de construire un immeuble et si oui ca surface au plancher maximum est de {surface_au_plancher_maximum} m² et trouve le nombre d'étage maximum.
Voici la loi :{loi}
Voici les infos sur la parcelle : {info_parcelle}
Renvoie l'inforamtion uniquement sous la forme suivante :
Maison : oui/non, surface au plancher maximum : {surface_au_plancher_maximum} m², nombre d'étage maximum : Y, **explication : texte explicatif
Immeuble : oui/non, surface au plancher maximum : {surface_au_plancher_maximum} m², nombre d'étage maximum : Y, **explication : texte explicatif
"""
    response = client.chat.completions.create(
        temperature=0.0,
        model="gpt-4o",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    output_text = response.choices[0].message.content.strip()
    return output_text
