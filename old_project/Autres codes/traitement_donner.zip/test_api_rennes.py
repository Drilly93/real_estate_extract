import requests

# URL de l'API
url = "https://data.rennesmetropole.fr/api/explore/v2.1/catalog/datasets/plui-de-rennes-metropole-plan-thematique-des-regles-du-coefficient-de-vegetalisa/files/b37250a743e77a50444edbd87285f698"

# Envoyer une requête GET
response = requests.get(url)

# Vérifier si la requête a réussi (code 200)
if response.status_code == 200:
    try:
        # Essayer de décoder la réponse en JSON
        data = response.json()
        print("Données récupérées :", data)
    except ValueError:
        # Si ce n'est pas du JSON, imprimer le contenu en texte brut
        print("Réponse reçue (texte brut) :", response.text)
else:
    print("Erreur lors de la récupération des données. Code de statut :", response.status_code)
