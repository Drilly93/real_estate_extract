import re
import requests
import base64
from io import BytesIO
from pdfminer.high_level import extract_text
import pandas as pd



def extract_pdf_text_from_onclick(url: str) -> str:
    # Étape 2 : Appeler l’API
    response = requests.get(url)
    if response.status_code != 200:
        raise ValueError(f"Failed to fetch data. Status code: {response.status_code}")
    
    json_data = response.json()
    if "payload" not in json_data:
        raise ValueError("Missing 'payload' in API response")

    # Étape 3 : Décoder le PDF en base64
    pdf_data = base64.b64decode(json_data["payload"])

    # Étape 4 : Extraire le texte du PDF
    pdf_file = BytesIO(pdf_data)
    text = extract_text(pdf_file)
    return text

test = "https://api-urba.sig.rennesmetropole.fr/v1/nru/350051000AZ0694"
#print(extract_pdf_text_from_onclick(test))

df = pd.read_csv(r"C:\Users\mathe\OneDrive\Bureau\M1\S2\ML_project\projet\ValeursFoncieres\ValeursFoncieresFrance.csv", sep=";")
print(df.columns)

print(df["id_parcelle"].head())
