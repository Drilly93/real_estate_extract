import geopandas as gpd
import pandas as pd
from shapely.geometry import Point
from geopy.geocoders import Nominatim
import time


def donne_zone(adresse):
    gdf_plui = gpd.read_file("data/data_geo/plui_synthese_2024.gpkg")
    df_csv = pd.read_csv("data/data_geo/plui_synthese_2024.csv", delimiter=";")
    if 'id_plui_synthese_2024' in df_csv.columns and 'id_plui_synthese_2024' in gdf_plui.columns:
        gdf_plui = gdf_plui.merge(df_csv, on="id_plui_synthese_2024", how="left")
    else:
        raise ValueError("Les colonnes 'id_plui_synthese_2024' ne sont pas présentes dans les deux fichiers.")
    geolocator = Nominatim(user_agent="plui_geocoder")
    location = None
    try:
        location = geolocator.geocode(adresse)
        time.sleep(1)
    except Exception as e:
        print("Erreur lors du géocodage :", e)

    if location:
        point = Point(location.longitude, location.latitude)
        gdf_point = gpd.GeoDataFrame([[adresse, point]], columns=["adresse", "geometry"], crs="EPSG:4326")

        if gdf_plui.crs != gdf_point.crs:
            gdf_point = gdf_point.to_crs(gdf_plui.crs)
        point_geom = gdf_point.iloc[0].geometry
        zones_trouvees = gdf_plui[gdf_plui.contains(point_geom)]
        
        if not zones_trouvees.empty:
            id_zone = zones_trouvees['id_plui_synthese_2024'].unique()
        else:
            return None
    else:
        return None

    libelle = df_csv[df_csv['id_plui_synthese_2024'] == id_zone[0]]
    return libelle['libelle'].values[0] if not libelle.empty else None

    