from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import pandas as pd
import polars as pl
import wget
import os


path_fichier_departement_france =  "depart.csv"
path_telechargement =  "test_ValeursFoncieres_depart\\"
path_fichier_unique = "ValeursFoncieres\\"
url = "https://dvf-api.data.gouv.fr/dvf/csv/?dep="

data_frame = pd.read_csv(path_fichier_departement_france)
departement = data_frame[["code_departement","nom_departement"]]

type_column_csv = {
    "id_mutation" : pl.Utf8,
    "date_mutation" : pl.Utf8, # aaaa-mm-jj
    "numero_disposition" : pl.Utf8,
    "nature_mutation" : pl.Utf8,
    "valeur_fonciere" : pl.Utf8,
    "adresse_numero" : pl.Utf8,
    "adresse_suffixe" : pl.Utf8,
    "adresse_nom_voie" : pl.Utf8,
    "adresse_code_voie" : pl.Utf8,
    "code_postal" : pl.Utf8,
    "code_commune" : pl.Utf8,
    "nom_commune" : pl.Utf8,
    "code_departement" : pl.Utf8,
    "ancien_code_commune" : pl.Utf8 ,
    "ancien_nom_commune" : pl.Utf8,
    "id_parcelle" : pl.Utf8 ,
    "ancien_id_parcelle" : pl.Utf8,
    "numero_volume" : pl.Utf8,
    "lot1_numero" : pl.Utf8 ,
    "lot1_surface_carrez" : pl.Utf8,
    "lot2_numero" : pl.Utf8,
    "lot2_surface_carrez" : pl.Utf8,
    "lot3_numero" : pl.Utf8,
    "lot3_surface_carrez" : pl.Utf8,
    "lot4_numero" : pl.Utf8,
    "lot4_surface_carrez" : pl.Utf8,
    "lot5_numero" : pl.Utf8,
    "lot5_surface_carrez" : pl.Utf8,
    "nombre_lots" : pl.Utf8,
    "code_type_local" : pl.Utf8,
    "type_local" : pl.Utf8,
    "surface_reelle_bati" : pl.Utf8,
    "nombre_pieces_principales" : pl.Utf8,
    "code_nature_culture" : pl.Utf8,
    "nature_culture" : pl.Utf8,
    "code_nature_culture_speciale" : pl.Utf8,
    "nature_culture_speciale" : pl.Utf8,
    "surface_terrain" : pl.Utf8,
    "longitude" : pl.Utf8,
    "latitude" : pl.Utf8,
    "section_prefixe" : pl.Utf8
}



def telechargement_valeur_fronciere_departement():
    for i in range(len(departement["code_departement"])):
        
        os.makedirs(path_telechargement + departement.iloc[i,0], exist_ok = True)
        chemin_fichier = os.path.join(path_telechargement + departement.iloc[i,0],departement.iloc[i,0] + ".csv")
        wget.download(url + departement.iloc[i,0],chemin_fichier)
 
        
def fichier_unique_valeur_fonciere():
    #On utilise polars... Pandas on a des out of memory
    liste_data_frame = []
    for i in range(len(departement["code_departement"])):
            
        try :
            df = pl.read_csv(path_telechargement + departement.iloc[i,0] + '\\' + departement.iloc[i,0] + '.csv',schema_overrides = type_column_csv)
            liste_data_frame.append(df)
        except pl.exceptions.NoDataError:
            print("Fichier",departement.iloc[i,0],".csv est vide. Departement  : ",departement.iloc[i,1])
            
        
    
        
    print("Merged_en_Cours")
    merged_df = pl.concat(liste_data_frame)
    # Sauvegarder dans un fichier CSV
    merged_df.write_csv(path_fichier_unique + 'ValeursFoncieresFrance.csv', separator=',')
    print("Fusion terminée et fichier CSV créé !")
    
telechargement_valeur_fronciere_departement()
fichier_unique_valeur_fonciere()

