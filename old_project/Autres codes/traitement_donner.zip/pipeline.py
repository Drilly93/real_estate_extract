from info_parcelle import chercher_parcelle, extract_pdf_bytes, extract_text_from_pdf_bytes
from trouver_zone_gpt import analyse_zone, construction_possible
from pathlib import Path

chemin_info_zone = Path(__file__).parent / "data" / "data_fiche_zone" 

addresse = input("Entrez l'adresse à annalyser : ")
numero_parcelle = chercher_parcelle(addresse)
url = "https://api-urba.sig.rennesmetropole.fr/v1/nru/350" + numero_parcelle[2:]
pdf = extract_pdf_bytes(url)
info_parcelle = extract_text_from_pdf_bytes(pdf)
zone = analyse_zone(info_parcelle).split(",")

liste_info_zone = []
for i in zone:
    chemin = chemin_info_zone / f"{i}.txt"
    with open(chemin, "r", encoding="utf-8") as file:
        texte = file.read()
        liste_info_zone.append(texte)
    
loi = "\n".join(liste_info_zone)
print(construction_possible(info_parcelle, loi))

