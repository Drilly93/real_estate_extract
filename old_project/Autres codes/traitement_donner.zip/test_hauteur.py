import json
import pandas as pd

# Ouvrir et charger le fichier GeoJSON
with open(r"C:\Users\mathe\OneDrive\Bureau\M1\S2\ML_project\projet\data\data_geo\hauteurs_rennes.geojson.application", "r", encoding="utf-8") as f:
    data = json.load(f)

# Vérifier que le fichier contient bien une clé "features"
features = data.get("features", [])
if not features:
    print("Aucune entité trouvée dans le fichier GeoJSON.")
else:
    # Extraire les données de chaque entité
    extracted_data = []
    for feature in features:
        # Extraction des propriétés (données associées à l'entité)
        properties = feature.get("properties", {})
        # Facultatif : extraire la géométrie et ses coordonnées
        geometry = feature.get("geometry", {})
        coordinates = geometry.get("coordinates", None)
        
        # On peut ajouter les coordonnées aux propriétés si désiré
        properties["coordinates"] = coordinates
        
        extracted_data.append(properties)

    # Conversion des données extraites en DataFrame pour une manipulation ou une exportation facile
    df = pd.DataFrame(extracted_data)
    
    # Affichage des premières lignes du DataFrame
    print("Aperçu des données extraites :")
    print(df.head())
    
    # Facultatif : sauvegarder les données sous forme de CSV
    df.to_csv("hauteurs_rennes_extrait.csv", index=False, encoding="utf-8")
    print("Les données ont été sauvegardées dans 'hauteurs_rennes_extrait.csv'")
