import matplotlib.pyplot as plt
import pandas as pd
import polars as pl
import wget
import os


from pathlib import Path
CURRENT_FILE_PATH = Path(__file__).parent.resolve() #
os.chdir(CURRENT_FILE_PATH)

from config import PATH_FICHIER_DEP_FR ,PATH_FICHIER_VAL_FONCIERE_FRANCE # FICHIER
from config import PATH_DIR_VAL_FONCIERE_DEP, PATH_DIR_VAL_FONCIERE_FRANCE # Directory/Dossier
from config import URL_VAL_FONCIERE, TYPE_COLUMN_CSV_SALE, COLUMN_FINAL, TYPE_COLUMN_CSV_PROPRE # Constante Utile






df_departement = pd.read_csv(PATH_FICHIER_DEP_FR)
df_departement = df_departement[["code_departement","nom_departement"]]


def telechargement_valeur_fronciere_departement():
    for i in range(len(df_departement["code_departement"])):  
        os.makedirs(PATH_DIR_VAL_FONCIERE_DEP / df_departement.iloc[i,0], exist_ok = True)
        chemin_fichier = os.path.join(PATH_DIR_VAL_FONCIERE_DEP / df_departement.iloc[i,0] / (df_departement.iloc[i,0] + ".csv"))
        wget.download(URL_VAL_FONCIERE + df_departement.iloc[i,0],chemin_fichier)
     
def nettoyage_donnee():
    
    
    print("NETTOYAGE EN COURS")
    
    #On utilise polars car avec pandas on a des out of memory avec un ordinateur classique
    liste_data_frame = []
    for i in range(len(df_departement["code_departement"])):
            
        try :
            df = pl.read_csv(PATH_DIR_VAL_FONCIERE_DEP / df_departement.iloc[i,0] / (df_departement.iloc[i,0] + '.csv'), schema_overrides = TYPE_COLUMN_CSV_SALE)
        except pl.exceptions.NoDataError:
            print("Fichier",df_departement.iloc[i,0],".csv est vide. Auncune donnee pour Departement  : ",df_departement.iloc[i,1])
            continue
        
        
        #----------NETTOYAGE----------
        
        #Selectionne les features interessantes
        df = df.select(COLUMN_FINAL)
        
        
        #On garde que les ventes 
        df = df.filter(pl.col("nature_mutation").is_in(["Vente", 
                                                        "Vente en l'état futur d'achèvement", 
                                                        "Vente terrain à bâtir"]))
        
        # On s'interesse au maison et au appart
        df= df.filter(pl.col("type_local").fill_null("").is_in(["Appartement","Maison"]))
        
        
        df = df.filter(pl.col("valeur_fonciere").is_not_null()) 
        
        # ATTENTION CES LIGNES en dessous NE DOIVENT PAS ETRE EXECUTE !
        # SURFACE TERRAIN a NULL pour les APPART. 
        # On perd une grande parti des donnee des APPART si on enleve ligne surface terrain == NULL
        
        #df = df.filter(pl.col("surface_reelle_bati").is_not_null())
        #df = df.filter(pl.col("surface_terrain").is_not_null())
        
        
        # DEF  surface_reelle_bati = surface habitable
        #      surface_terrain = surface habitable plus jardin ou autre
        # SOLUTION TROUVEE : on met a zero si NULL (ou plutot 0.000001, on divisera pour avoir prix au metre carre....)
        
        #Changement de type et valeur null mis a zero.
        #Valable de faire si different [^0-9.] alors mettre a 0 ....Nous reste que valeur null ou des chiffres...
        df = df.with_columns([pl.col("surface_reelle_bati").str.replace_all(r"[^0-9.]", "0.00001").cast(pl.Float64),
                             pl.col("surface_terrain").str.replace_all(r"[^0-9.]", "0.00001").cast(pl.Float64),
                             pl.col("valeur_fonciere").str.replace_all(r"[^0-9.]", "0").cast(pl.Float64),
                             pl.col("date_mutation").str.strptime(pl.Date, "%Y-%m-%d")])

        
        
        #Rajout d'une colonne annee_mois,  Format YYYY-MM (année-mois) utile pour les plots
        df = df.with_columns([pl.col("date_mutation").dt.strftime("%Y-%m").alias("annee_mois"),
                             pl.col("date_mutation").dt.year().alias("annee")]) # Ajoute la colonne année
        
        
        # Valeur Aberantes ?
        #df = df.filter((pl.col("surface_terrain") > 5) & (pl.col("valeur_fonciere") > 100))
        
       
        # Calcul prix metre carre
        df = df.with_columns([(pl.col("valeur_fonciere") / pl.col("surface_reelle_bati")).alias("prix_par_m2_habitable"),
                             (pl.col("valeur_fonciere") / pl.col("surface_terrain")).alias("prix_par_m2_terrain")])
    
        #Supprime les doublons si existant
        df = df.unique(subset=['date_mutation','longitude', 'latitude', 'valeur_fonciere', 'surface_terrain']) 
        liste_data_frame.append(df.clone())
        
        
    merged_df = pl.concat(liste_data_frame)
    
    # Sauvegarder dans un fichier CSV
    merged_df.write_csv(PATH_FICHIER_VAL_FONCIERE_FRANCE)
    
    print("------BILAN-----")
    print("Nombre de Donnee apres netoyyage",merged_df.shape[0])
    print("Nombre de Donnee Maison",merged_df.filter(pl.col("type_local") == "Maison").shape[0])
    print("Nombre de Donnee Appart",merged_df.filter(pl.col("type_local") == "Appartement").shape[0])

    print(df.select(['valeur_fonciere','prix_par_m2_habitable','prix_par_m2_terrain']).describe())




def plot_evolution_mettre_carre(df, time_col, title):
    #Evolution du prix au metre carre selon annee_mois ou annne
    
    df_pd = df.to_pandas().groupby(time_col)['prix_par_m2_habitable'].agg(['mean', 'median']).reset_index()

    plt.plot(df_pd[time_col], df_pd["mean"], marker='', color='purple', label="Prix moyen",linewidth=1)
    plt.plot(df_pd[time_col], df_pd["median"], marker='', color='red', label="Prix médian",linewidth=1)
    plt.xlabel("Temps")
    plt.ylabel("Prix par m_carre (€)")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


    plt.plot(df_pd[time_col], df_pd["median"], marker='', color='red', label="Prix médian",linewidth=1)
    plt.xlabel("Temps")
    plt.ylabel("Prix par m_carre (€)")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot_evolution(liste_type_local, time_col,title):
    
    df = pl.read_csv(PATH_FICHIER_VAL_FONCIERE_FRANCE, schema_overrides=TYPE_COLUMN_CSV_PROPRE)
    df = df.filter(pl.col("type_local").is_in(liste_type_local)).select([time_col, "prix_par_m2_habitable"])
    plot_evolution_mettre_carre(df, time_col, title)




#telechargement_valeur_fronciere_departement()
nettoyage_donnee()

#plot_evolution(["Maison"], "annee", "Prix metre carre , Maison, annee")
#plot_evolution(["Appartement"], "annee", "Prix metre carre , Appart, annee")
#plot_evolution(["Appartement", "Maison"], "annee", "Prix metre carre , Appart et Maison, annee")

plot_evolution(["Maison"], "annee_mois", "Evolution du prix du metre carre : Maison")
plot_evolution(["Appartement"], "annee_mois", "Evolution du prix du metre carre : Appart")
plot_evolution(["Appartement", "Maison"], "annee_mois", "Evolution du prix du metre carre : Appart et Maison")




