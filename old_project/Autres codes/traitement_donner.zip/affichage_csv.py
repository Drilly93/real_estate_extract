import pandas as pd

# Chemin de ton fichier
input_file = r"data/data_immeuble/dpe_logement.csv"
output_file = r"data/data_immeuble/dpe_logement.csv"

# Chargement du fichier CSV avec son séparateur initial (ici supposé être une virgule)
df = pd.read_csv(input_file, sep=',')

# Sauvegarde avec ';' comme séparateur
df.to_csv(output_file, sep=';', index=False)

print(f"Le fichier a été transformé et sauvegardé en : {output_file}")
