import pandas as pd

df = pd.read_parquet(r"C:\Users\mathe\Downloads\donnee-comm-data.gouv-parquet-2023-geographie2024-produit-le2024-07-05.parquet")

# Sauvegarder en CSV
df.to_csv("converted_file.csv", index=False)
